package com.nyx3n.client;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class Nyx3nHud {
    private static int frameCount = 0;
    private static int displayFps = 0;
    private static long lastFpsSampleNs = System.nanoTime();

    private Nyx3nHud() {}

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of(Nyx3nClientMod.MOD_ID, "status_hud"),
                Nyx3nHud::render
        );
    }

    private static void updateFps() {
        frameCount++;
        long now = System.nanoTime();
        if (now - lastFpsSampleNs >= 1_000_000_000L) {
            displayFps = frameCount;
            frameCount = 0;
            lastFpsSampleNs = now;
        }
    }

    private static void render(DrawContext drawContext, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) {
            return;
        }

        updateFps();

        Nyx3nConfig cfg = Nyx3nClientMod.getConfig();
        Nyx3nEngine engine = Nyx3nClientMod.getEngine();
        boolean enabled = cfg.masterEnabled;

        List<String> lines = new ArrayList<>();
        String title = enabled ? "NYX3N v11 [M]: ACTIVE" : "NYX3N v11 [M]: PAUSED";
        if (cfg.showFpsHud) {
            title = title + " | " + displayFps + " FPS";
        }
        lines.add(title);

        if (enabled) {
            lines.add("Task: " + engine.getStatusText());
            if (cfg.mobRadarHud && !engine.getRadarText().isEmpty()) {
                lines.add(engine.getRadarText());
            }
            if (cfg.nightAlert && client.world != null) {
                long tod = client.world.getTimeOfDay() % 24000L;
                if (tod >= 12500L && tod <= 23500L) {
                    lines.add("ALERT: NIGHT TIME!");
                }
            }
        }

        int padding = 5;
        int lineHeight = 10;
        int maxW = 0;
        for (String line : lines) {
            maxW = Math.max(maxW, client.textRenderer.getWidth(line));
        }
        int width = maxW + padding * 2 + 4;
        int height = lines.size() * lineHeight + padding * 2;

        int screenW = client.getWindow().getScaledWidth();
        int screenH = client.getWindow().getScaledHeight();
        int x;
        int y;
        if (cfg.hudPosition == 0) {
            x = Math.max(8, screenW - width - 8);
            y = 42;
        } else if (cfg.hudPosition == 1) {
            x = (screenW - width) / 2;
            y = 8;
        } else {
            x = 8;
            y = 8;
        }

        int bgColor = enabled ? 0xCC09121A : 0x99091016;
        int accentColor = enabled ? 0xFF10F5A8 : 0xFFEF4444;
        int borderColor = enabled ? 0xFF1E3F50 : 0xFF2B2428;

        drawContext.fill(x - 1, y - 1, x + width + 1, y + height + 1, borderColor);
        drawContext.fill(x, y, x + width, y + height, bgColor);
        drawContext.fill(x, y, x + 3, y + height, accentColor);

        for (int i = 0; i < lines.size(); i++) {
            int color = switch (i) {
                case 0 -> enabled ? 0xFF34F5C5 : 0xFFF87171;
                case 1 -> 0xFFFDE68A;
                default -> 0xFFFCA5A5;
            };
            drawContext.drawTextWithShadow(
                    client.textRenderer,
                    lines.get(i),
                    x + padding + 2,
                    y + padding + i * lineHeight,
                    color
            );
        }

        // Render Neon Keystrokes HUD (WASD + LMB/RMB + SPACE)
        if (cfg.showKeystrokes) {
            int ksX = (cfg.hudPosition == 0) ? Math.max(8, screenW - 76) : 8;
            int ksY = y + height + 8;
            if (ksY + 72 > screenH) {
                ksY = Math.max(8, screenH - 78);
            }
            renderKeystrokes(drawContext, client, ksX, ksY);
        }

        // Ochiski-style Hit Distance Display above hotbar
        String distText = engine.getHitDistanceText();
        if (!distText.isEmpty()) {
            int tw = client.textRenderer.getWidth(distText);
            drawContext.drawTextWithShadow(client.textRenderer, distText, (screenW - tw) / 2, screenH - 52, 0xFF34F5C5);
        }

        // Right-side Sword + Armor Durability HUD
        if (cfg.showArmorHud) {
            renderArmorHud(drawContext, client, screenW, screenH);
        }
    }

    private static void renderKeystrokes(DrawContext ctx, MinecraftClient client, int x, int y) {
        int s = 20;
        int g = 2;

        // Row 1: W
        drawKey(ctx, client, x + s + g, y, s, s, "W", client.options.forwardKey.isPressed());

        // Row 2: A S D
        int row2 = y + s + g;
        drawKey(ctx, client, x, row2, s, s, "A", client.options.leftKey.isPressed());
        drawKey(ctx, client, x + s + g, row2, s, s, "S", client.options.backKey.isPressed());
        drawKey(ctx, client, x + (s + g) * 2, row2, s, s, "D", client.options.rightKey.isPressed());

        // Row 3: LMB / RMB
        int row3 = row2 + s + g;
        int halfW = (s * 3 + g * 2 - g) / 2;
        drawKey(ctx, client, x, row3, halfW, 16, "LMB", client.options.attackKey.isPressed());
        drawKey(ctx, client, x + halfW + g, row3, halfW, 16, "RMB", client.options.useKey.isPressed());

        // Row 4: SPACE
        int row4 = row3 + 16 + g;
        drawKey(ctx, client, x, row4, s * 3 + g * 2, 14, "SPACE", client.options.jumpKey.isPressed());
    }

    private static void drawKey(DrawContext ctx, MinecraftClient client, int x, int y, int w, int h, String label, boolean pressed) {
        int bg = pressed ? 0xDD10F5A8 : 0xAA0A121A;
        int border = pressed ? 0xFF34F5C5 : 0xFF1E3A4C;
        int textColor = pressed ? 0xFF041A12 : 0xFFE2F1F8;

        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, border);
        ctx.fill(x, y, x + w, y + h, bg);

        int tw = client.textRenderer.getWidth(label);
        int tx = x + (w - tw) / 2;
        int ty = y + (h - 8) / 2;
        ctx.drawTextWithShadow(client.textRenderer, label, tx, ty, textColor);
    }

    private static void renderArmorHud(DrawContext ctx, MinecraftClient client, int screenW, int screenH) {
        if (client.player == null) return;
        List<String> durLines = new ArrayList<>();
        ItemStack hand = client.player.getMainHandStack();
        if (!hand.isEmpty() && hand.isDamageable()) {
            durLines.add("WPN: " + (hand.getMaxDamage() - hand.getDamage()));
        }
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        String[] labels = {"H", "C", "L", "B"};
        for (int i = 0; i < slots.length; i++) {
            ItemStack eq = client.player.getEquippedStack(slots[i]);
            if (!eq.isEmpty() && eq.isDamageable()) {
                durLines.add(labels[i] + ": " + (eq.getMaxDamage() - eq.getDamage()));
            }
        }
        if (durLines.isEmpty()) return;

        int startY = screenH - 12 - durLines.size() * 10;
        for (int i = 0; i < durLines.size(); i++) {
            String line = durLines.get(i);
            int tw = client.textRenderer.getWidth(line);
            ctx.drawTextWithShadow(client.textRenderer, line, screenW - tw - 8, startY + i * 10, 0xFF93C5FD);
        }
    }
}
