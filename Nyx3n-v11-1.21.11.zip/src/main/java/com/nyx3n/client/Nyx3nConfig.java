package com.nyx3n.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class Nyx3nConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("nyx3n-client.json");

    public boolean masterEnabled = true;

    // Page 1: Exact v4 Combat & Core Actions
    public boolean ochiskiMode = false;
    public boolean sharpnessMode = false;
    public boolean geminiStyle = false;
    public boolean kpsMode = false;
    public boolean jokingMode = false;
    public boolean comboBreaker = true;
    public boolean autoCombat = true;
    public boolean playerRetaliate = true;
    public boolean ht3CritCombo = true;
    public boolean ht3CrowdStrafe = true;
    public boolean autoShield = true;
    public boolean antiCreeper = true;
    public boolean treeChopper = false;
    public boolean autoMining = false;
    public boolean buildHouse = false;
    public boolean ironGolemCheese = false;

    // Page 2: Survival, FPS Counter & Keystrokes HUD
    public boolean showFpsHud = true;
    public boolean showKeystrokes = true;
    public boolean showArmorHud = true;
    public boolean autoEat = true;
    public boolean autoTool = true;
    public boolean autoCollectDrops = true;
    public boolean autoSprint = true;
    public boolean autoJump = true;
    public boolean waterRescue = true;
    public boolean lowHpRetreat = false;
    public boolean leafCleaner = true;
    public boolean mobRadarHud = true;
    public boolean nightAlert = true;

    public int hudPosition = 0;

    public String getHudPositionLabel() {
        return switch (hudPosition) {
            case 0 -> "TOP-RIGHT";
            case 1 -> "TOP-CENTER";
            default -> "TOP-LEFT";
        };
    }

    public void cycleHudPosition() {
        hudPosition = (hudPosition + 1) % 3;
        save();
    }

    public void panicStopAll() {
        masterEnabled = false;
        treeChopper = false;
        autoMining = false;
        buildHouse = false;
        autoCombat = false;
        playerRetaliate = false;
        ochiskiMode = false;
        sharpnessMode = false;
        geminiStyle = false;
        kpsMode = false;
        jokingMode = false;
        ironGolemCheese = false;
        save();
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(this));
        } catch (Exception ignored) {
        }
    }

    public static Nyx3nConfig load() {
        try {
            if (Files.exists(CONFIG_PATH)) {
                String json = Files.readString(CONFIG_PATH);
                Nyx3nConfig loaded = GSON.fromJson(json, Nyx3nConfig.class);
                if (loaded != null) return loaded;
            }
        } catch (Exception ignored) {
        }
        Nyx3nConfig fresh = new Nyx3nConfig();
        fresh.save();
        return fresh;
    }
}
