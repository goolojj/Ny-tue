package com.nyx3n.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class Nyx3nMenuScreen extends Screen {
    private int page = 0;

    public Nyx3nMenuScreen() {
        super(Text.literal("NYX3N v11 Control Menu"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        super.init();
        rebuildButtons();
    }

    private void ensureActiveIfTurningOn(boolean nowOn) {
        if (nowOn) {
            Nyx3nClientMod.getConfig().masterEnabled = true;
        }
    }

    private void rebuildButtons() {
        this.clearChildren();
        Nyx3nConfig cfg = Nyx3nClientMod.getConfig();

        int colW = 152;
        int btnH = 20;
        int gapX = 10;
        int gapY = 4;
        int startX = this.width / 2 - colW - (gapX / 2);
        int startY = 44;

        if (page == 0) {
            addToggle(startX, startY, colW, btnH, "Player Retaliate", cfg.playerRetaliate, () -> {
                cfg.playerRetaliate = !cfg.playerRetaliate;
                ensureActiveIfTurningOn(cfg.playerRetaliate);
            });
            addToggle(startX + colW + gapX, startY, colW, btnH, "Auto Combat", cfg.autoCombat, () -> {
                cfg.autoCombat = !cfg.autoCombat;
                ensureActiveIfTurningOn(cfg.autoCombat);
            });

            addToggle(startX, startY + (btnH + gapY), colW, btnH, "Gemini Style", cfg.geminiStyle, () -> {
                cfg.geminiStyle = !cfg.geminiStyle;
                if (cfg.geminiStyle) {
                    cfg.ochiskiMode = false;
                    cfg.sharpnessMode = false;
                }
                ensureActiveIfTurningOn(cfg.geminiStyle);
            });
            addToggle(startX + colW + gapX, startY + (btnH + gapY), colW, btnH, "HT3 1v4 Strafe", cfg.ht3CrowdStrafe, () -> {
                cfg.ht3CrowdStrafe = !cfg.ht3CrowdStrafe;
                ensureActiveIfTurningOn(cfg.ht3CrowdStrafe);
            });

            addToggle(startX, startY + (btnH + gapY) * 2, colW, btnH, "Ochiski Mode", cfg.ochiskiMode, () -> {
                cfg.ochiskiMode = !cfg.ochiskiMode;
                if (cfg.ochiskiMode) { cfg.sharpnessMode = false; cfg.geminiStyle = false; }
                ensureActiveIfTurningOn(cfg.ochiskiMode);
            });
            addToggle(startX + colW + gapX, startY + (btnH + gapY) * 2, colW, btnH, "Sharpness Mode", cfg.sharpnessMode, () -> {
                cfg.sharpnessMode = !cfg.sharpnessMode;
                if (cfg.sharpnessMode) { cfg.ochiskiMode = false; cfg.geminiStyle = false; }
                ensureActiveIfTurningOn(cfg.sharpnessMode);
            });

            addToggle(startX, startY + (btnH + gapY) * 3, colW, btnH, "Tree Chopper", cfg.treeChopper, () -> {
                cfg.treeChopper = !cfg.treeChopper;
                ensureActiveIfTurningOn(cfg.treeChopper);
            });
            addToggle(startX + colW + gapX, startY + (btnH + gapY) * 3, colW, btnH, "Auto Mining", cfg.autoMining, () -> {
                cfg.autoMining = !cfg.autoMining;
                ensureActiveIfTurningOn(cfg.autoMining);
            });

            addToggle(startX, startY + (btnH + gapY) * 4, colW, btnH, "Build House", cfg.buildHouse, () -> {
                cfg.buildHouse = !cfg.buildHouse;
                if (cfg.buildHouse) {
                    Nyx3nClientMod.getEngine().resetHousePlan();
                    ensureActiveIfTurningOn(true);
                }
            });
            addToggle(startX + colW + gapX, startY + (btnH + gapY) * 4, colW, btnH, "Golem 3-Block", cfg.ironGolemCheese, () -> {
                cfg.ironGolemCheese = !cfg.ironGolemCheese;
                ensureActiveIfTurningOn(cfg.ironGolemCheese);
            });
        } else {
            addToggle(startX, startY, colW, btnH, "Master Switch", cfg.masterEnabled, () -> {
                Nyx3nClientMod.getEngine().toggleMaster(this.client);
            });
            addToggle(startX + colW + gapX, startY, colW, btnH, "Auto-Eat", cfg.autoEat, () -> cfg.autoEat = !cfg.autoEat);

            addToggle(startX, startY + (btnH + gapY), colW, btnH, "Auto-Tool", cfg.autoTool, () -> cfg.autoTool = !cfg.autoTool);
            addToggle(startX + colW + gapX, startY + (btnH + gapY), colW, btnH, "Collect Drops", cfg.autoCollectDrops, () -> cfg.autoCollectDrops = !cfg.autoCollectDrops);

            addToggle(startX, startY + (btnH + gapY) * 2, colW, btnH, "FPS Counter", cfg.showFpsHud, () -> { cfg.showFpsHud = !cfg.showFpsHud; cfg.save(); });
            addToggle(startX + colW + gapX, startY + (btnH + gapY) * 2, colW, btnH, "Keystrokes HUD", cfg.showKeystrokes, () -> { cfg.showKeystrokes = !cfg.showKeystrokes; cfg.save(); });

            addToggle(startX, startY + (btnH + gapY) * 3, colW, btnH, "Armor HUD", cfg.showArmorHud, () -> cfg.showArmorHud = !cfg.showArmorHud);
            addToggle(startX + colW + gapX, startY + (btnH + gapY) * 3, colW, btnH, "Anti-Creeper 12m", cfg.antiCreeper, () -> cfg.antiCreeper = !cfg.antiCreeper);

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("HUD: " + cfg.getHudPositionLabel()),
                    btn -> {
                        cfg.cycleHudPosition();
                        rebuildButtons();
                    }
            ).dimensions(startX, startY + (btnH + gapY) * 4, colW, btnH).build());

            this.addDrawableChild(ButtonWidget.builder(
                    Text.literal("\u00A7cPANIC STOP ALL"),
                    btn -> {
                        cfg.panicStopAll();
                        if (this.client != null) {
                            Nyx3nClientMod.getEngine().forceStop(this.client);
                        }
                        rebuildButtons();
                    }
            ).dimensions(startX + colW + gapX, startY + (btnH + gapY) * 4, colW, btnH).build());
        }

        int navY = startY + (btnH + gapY) * 5 + 8;
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal(page == 0 ? "Page 2: Survival & HUD ->" : "<- Page 1: PvP & AI"),
                btn -> {
                    page = (page == 0) ? 1 : 0;
                    rebuildButtons();
                }
        ).dimensions(startX, navY, 198, btnH).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("\u00A7aDone"),
                btn -> this.close()
        ).dimensions(startX + 206, navY, 108, btnH).build());
    }

    private void addToggle(int x, int y, int w, int h, String name, boolean state, Runnable action) {
        String label = name + ": " + (state ? "\u00A7aON" : "\u00A7cOFF");
        this.addDrawableChild(ButtonWidget.builder(Text.literal(label), btn -> {
            action.run();
            Nyx3nClientMod.getConfig().save();
            rebuildButtons();
        }).dimensions(x, y, w, h).build());
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderBackground(context, mouseX, mouseY, delta);
        int panelW = 336;
        int panelH = 204;
        int px = this.width / 2 - panelW / 2;
        int py = 16;

        context.fill(px - 2, py - 2, px + panelW + 2, py + panelH + 2, 0xFF10F5A8);
        context.fill(px, py, px + panelW, py + panelH, 0xE6081118);

        String header = page == 0
                ? "NYX3N v11 — HT3 PvP & AI (1/2)"
                : "NYX3N v11 — Survival & HUD (2/2)";
        context.drawCenteredTextWithShadow(this.textRenderer, header, this.width / 2, py + 10, 0xFF34F5C5);
    }
}
