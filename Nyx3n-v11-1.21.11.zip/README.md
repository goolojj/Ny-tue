# NYX3N v11 (Minecraft 1.21.11 Fabric)

## What's New in NYX3N v11
- **Instant First-Hit Player & Mob Retaliation (`Player Retaliate: ON`)**: Whenever ANY player (like your friend in a LAN world) or ANY mob hits you first, NYX3N v11 immediately locks onto them using `hurtTime` + swinging-entity detection and unleashes **HT3 Jump-Crit + W-Tap Combo + Circle-Strafe** until they back off or get KO'd! (Never attacks friends unless they hit you first.)
- **No More Extra Master Switch Hassle**: Toggling ANY feature ON in the `M` Menu automatically activates the engine—no need to separately remember `Master AI`! Use `N`, `.off`, or `PANIC STOP ALL` to pause everything instantly.
- **Versioned Naming**: Clean `Nyx3n-v11-1.21.11.jar` output so you never mix up versions in your `mods` folder.
